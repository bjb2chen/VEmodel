#!/bin/bash
USER=$(whoami)
# assuming the user has TeXLive installed on OSX, execute from the local_packages directory
cd ..
ln -s $(pwd)/local_packages /Users/${USER}/Library/texmf/tex/latex/

